#pragma once
#include"Window.h"

class Window;

class BaseIcon
{
	float r;
	float g;
	float b;
protected:
	int x;
	int y;
	int width;
	int height;
public:
	BaseIcon(
		const int& x,
		const int& y,
		const int& width,
		const int& height,
		const float& r,
		const float& g,
		const float& b
		);
	virtual void draw(Window* window);
};

class Icon_c : public BaseIcon
{
private:
public:
	Icon_c
		(const int& x, const int& y, const int& width, const int& height, const float& r, const float& g, const float& b);
	virtual void draw(Window* window);
}; 
class Icon_s : public BaseIcon
{
private:
public:
	Icon_s
		(const int& x, const int& y, const int& width, const int& height, const float& r, const float& g, const float& b);
	virtual void draw(Window* window);
};