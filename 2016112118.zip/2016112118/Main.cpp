#include<iostream>
#include"Window.h"
#include"Icon.h"

int main()
{
	Window * main = new Window(1440, 810); //get window

	Window myDraw;

	//circle
	main->pushicon(Icon_c(200, 200, 200, 200, 1.0f, 1.0f, 1.0f));
	main->pushicon(Icon_s(200, 200, 200, 200, 1.0f, 1.0f, 1.0f));
	//square
	main->pushicon(Icon_s(500, 200, 200, 200, 1.0f, 1.0f, 1.0f));
	main->pushicon(Icon_s(500, 200, 300, 300, 1.0f, 1.0f, 1.0f));

	if (!main->init())
	{
		std::cout << "init error! " << std::endl;
		exit(1);
	}

	while (main->run());

	if (!main->destory())
	{
		std::cout << "destroy erroy! " << std::endl;
		exit(1);
	}
	delete main;
	return 0;
}