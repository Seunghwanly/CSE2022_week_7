#pragma once
#include <GLFW/glfw3.h>
#include<vector>
#include"Icon.h"
#include<stdbool.h>

class BaseIcon;

class Window
{
	
private:
	GLFWwindow* window;
	int width;
	int height;
	float * pixels;
	std::vector<BaseIcon*> Icon;

public:

	void (Window::*callback_)(void) = nullptr;

	Window(const int& width, const int& height);
	bool init();
	bool destory();
	bool run();
	void pushicon(BaseIcon& icon);
	void drawpixels(const int& i, const int& j, const float& red, const float& green, const float& blue);
	void drawline(const int& i0, const int& j0, const int& i1, const int& j1, const float& red, const float& green, const float& blue);
	~Window();

};