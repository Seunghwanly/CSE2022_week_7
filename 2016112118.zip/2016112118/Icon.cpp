#include "Icon.h"
#include<iostream>

BaseIcon::BaseIcon(
	const int& x,
	const int& y,
	const int& width,
	const int& height,
	const float& r,
	const float& g,
	const float& b
	)
{
	this->x = x; this->y = y; this->width = width; this->height = height; this->r = r; this->g = g; this->b = b;
}

Icon_c::Icon_c(
	const int& x,
	const int& y,
	const int& width,
	const int& height,
	const float& r,
	const float& g,
	const float& b
	)
	:BaseIcon(x, y, width, height, r, g, b)
{}

Icon_s::Icon_s(
	const int& x,
	const int& y,
	const int& width,
	const int& height,
	const float& r,
	const float& g,
	const float& b
	)
	: BaseIcon(x, y, width, height, r, g, b)
{}

void BaseIcon::draw(Window* window)
{

	window->drawline(x - width / 3, y - height / 3, x + width / 3, y - height / 3, this->r, this->g, this->b);
	window->drawline(x - width / 3, y + height / 3, x + width / 3, y + height / 3, this->r, this->g, this->b);
	window->drawline(x - width / 3, y - height / 3, x - width / 3, y + height / 3, this->r, this->g, this->b);
	window->drawline(x + width / 3, y - height / 3, x + width / 3, y + height / 3, this->r, this->g, this->b);
}

//draw circle
void Icon_c::draw(Window* window)
{
	BaseIcon::draw(window);
	{
		//drawing circle
		int x = this->width / 2;
		int y = 0;
		int err = 0;
		while (x >= y)
		{
			//red circle
			window->drawpixels(this->x + x, this->y + y, 1.0f, 0.0f, 0.0f);
			window->drawpixels(this->x + y, this->y + x, 1.0f, 0.0f, 0.0f);
			window->drawpixels(this->x - y, this->y + x, 1.0f, 0.0f, 0.0f);
			window->drawpixels(this->x - x, this->y + y, 1.0f, 0.0f, 0.0f);
			window->drawpixels(this->x - x, this->y - y, 1.0f, 0.0f, 0.0f);
			window->drawpixels(this->x - y, this->y - x, 1.0f, 0.0f, 0.0f);
			window->drawpixels(this->x + y, this->y - x, 1.0f, 0.0f, 0.0f);
			window->drawpixels(this->x + x, this->y - y, 1.0f, 0.0f, 0.0f);
			y += 1;
			err += 1 + 2 * y;
			if (2 * (err - x) + 1 > 0)
			{
				x -= 1;
				err += 1 - 2 * x;
			}
			//	x = this->width / 8;
		}
	}
}

//draw square
void Icon_s::draw(Window* window)
{
	BaseIcon::draw(window);
	window->drawline(x - width / 4, y - height / 4, x + width / 4, y - height / 4, 1.0f, 0.0f, 0.0f);
	window->drawline(x - width / 4, y - height / 4, x - width / 4, y + height / 4, 1.0f, 0.0f, 0.0f);
	window->drawline(x - width / 4, y + height / 4, x + width / 4, y + height / 4, 1.0f, 0.0f, 0.0f);
	window->drawline(x + width / 4, y - height / 4, x + width / 4, y + height / 4, 1.0f, 0.0f, 0.0f);
}
