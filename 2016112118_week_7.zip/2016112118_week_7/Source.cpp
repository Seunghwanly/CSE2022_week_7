#include <GLFW/glfw3.h>
#include <cstring>
#include <stdlib.h>		  // srand, rand
#include <thread>         // std::this_thread::sleep_for
#include <chrono>         // std::chrono::seconds
#include "math.h"
#include<iostream>
#include<vector>

using namespace std;

const int width = 640;
const int height = 480;

float* pixels = new float[width*height * 3];



void drawPixel(const int& i, const int& j, const float& red, const float& green, const float& blue)
{
	pixels[(i + width* j) * 3 + 0] = red;
	pixels[(i + width* j) * 3 + 1] = green;
	pixels[(i + width* j) * 3 + 2] = blue;
}

void drawLine(const int& i0, const int& j0, const int& i1, const int& j1, const float& red, const float& green, const float& blue)
{
	if ((i1 - i0) == 0)
	{
		for (int i = j0; i <= j1; i++)
		{
			drawPixel(i0, i, red, green, blue);
		}
	}
	else
	{
		for (int i = i0; i <= i1; i++)
		{
			const int j = (j1 - j0)*(i - i0) / (i1 - i0) + j0;

			drawPixel(i, j, red, green, blue);
		}
	}
}

void drawOnPixelBuffer()
{
	std::fill_n(pixels, width*height * 3, 1.0f);	// white background
}

void drawBox(const int& x,const int& y,const int& width, const int& height, const float& red, const float& green, const float& blue)
{
	// draw box here
	drawLine(x - width / 3, y - height / 3, x + width / 3, y - height / 3, red,green,blue);
	drawLine(x - width / 3, y + height / 3, x + width / 3, y + height / 3, red, green, blue);
	drawLine(x - width / 3, y - height / 3, x - width / 3, y + height / 3, red, green, blue);
	drawLine(x + width / 3, y - height / 3, x + width / 3, y + height / 3, red, green, blue);

}

void drawCircle(const int& x,const int& y, const int& width, const int& height, const float& red, const float& green, const float& blue)
{
	int x = width/2;
	int y = 0;
	int err = 0;
	// draw circle here
	while (x >= y)
	{
		drawPixel(x + x, y + y, red, green, blue);
		drawPixel(x + y, y + x, red, green, blue);
		drawPixel(x - y, y + x, red, green, blue);
		drawPixel(x - x, y + y, red, green, blue);
		drawPixel(x - x, y - y, red, green, blue);
		drawPixel(x - y, y - x, red, green, blue);
		drawPixel(x + y, y - x, red, green, blue);
		drawPixel(x + x, y - y, red, green, blue);
		y += 1;
		err += 1 + 2 * y;
		if (2 * (err - x) + 1 > 0)
		{
			x -= 1;
			err += 1 - 2 * x;
		}
	}
}

class GeometricObject
{
public:
	void (GeometricObject::*call_back)(void) = nullptr;

	void exec()
	{
		(this->*call_back)();
	}

	void drawBox_()
	{
		drawBox(200, 200, 100, 100, 1.0f, 1.0f, 1.0f);
	}
	void drawCircle_()
	{
		drawCircle(400, 200, 100, 100, 1.0f, 1.0f, 1.0f);
	}
	void drawBox_2()
	{
		drawBox(200, 200, 50, 50, 1.0f, 1.0f, 1.0f);
		drawBox(400, 200, 50, 50, 1.0f, 1.0f, 1.0f);
	}
};

int main(void)
{
	GLFWwindow* window;

	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(width, height, "2016112118", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	/* Make the window's context current */
	glfwMakeContextCurrent(window);
	glClearColor(1, 1, 1, 1); // while background

							  /* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		/* Render here */
		//glClear(GL_COLOR_BUFFER_BIT);

		drawOnPixelBuffer();

		GeometricObject G;
		G.drawBox_ = &GeometricObject::drawBox_2;


		glDrawPixels(width, height, GL_RGB, GL_FLOAT, pixels);

		/* Swap front and back buffers */
		glfwSwapBuffers(window);

		/* Poll for and process events */
		glfwPollEvents();

		std::this_thread::sleep_for(std::chrono::milliseconds(100));
	}

	glfwTerminate();

	delete[] pixels; // or you may reuse pixels array 

	return 0;
}